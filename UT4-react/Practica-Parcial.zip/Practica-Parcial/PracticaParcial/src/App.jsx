import { useState } from 'react'
import './App.css'
import { AltaJugadores } from './AltaJugadores/AltaJugadores'
import {  ListarJugadores } from './ListarJugadores/ListarJugadores';

export function App() {
  

  return(
    <ListarJugadores />
  );
}
